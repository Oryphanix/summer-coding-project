# weather/urls.py

from django.urls import path
from . import views  # Ensure you're importing your views

urlpatterns = [
    path('weather/', views.weather_view, name='weather'),  # Add your view function here
]
