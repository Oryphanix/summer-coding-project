from django.shortcuts import render
import requests


def weather_view(request):
    # Example weather API call (replace with your API endpoint and key)
    api_key = "1cc64fee075fbef9166e23f47dbe40f7"
    city = "London"
    url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}&units=metric"

    response = requests.get(url)
    weather_data = response.json()

    context = {
        'city': city,
        'temperature': weather_data['main']['temp'],
        'description': weather_data['weather'][0]['description'],
        'icon': weather_data['weather'][0]['icon'],
    }

    return render(request, 'weather.html', context)
