from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('', include('home.urls')),  # Add this line to include the home app's URLs
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('weather/', include('weather.urls')),  # Assuming weather app has its own URLs
]
