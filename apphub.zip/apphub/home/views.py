from django.shortcuts import render

# Define the home view
def home_view(request):
    return render(request, 'home/home.html')
