from django.urls import path
from .views import home_view  # Ensure correct import

urlpatterns = [
    path('', home_view, name='home'),  # Ensure correct path and view
]
